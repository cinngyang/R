#Apriori beer.xls beer.txt
library(xlsx)
library(arules)
beer=read.xlsx("d:\\stella\\R\\beer.xls",header=T,sheetIndex=1)
beer=as.matrix(beer)
rule=apriori(beer,parameter=list(supp=0.2,conf=0.8,maxlen=5))
inspect(rule)
summary(rule)
inspect(head(sort(rule,by="support"),10))

library(arules)
beer=read.table("d:\\stella\\R\\beer.txt",sep=",")
beer2=as(beer,"transactions")
beer2
rule=apriori(beer2,parameter=list(supp=0.2,conf=0.8,maxlen=5))
inspect(head(sort(rule,by="support"),10))

#Apriori shoppint.txt
library(arules)
shopping=read.csv("d:\\stella\\R\\shopping.txt",header=T)
head(shopping)
shopping=shopping[,1:10]
shopping=na.exclude(shopping)
shopping=as.matrix(shopping) 
#rule=apriori(shopping,parameter=list(supp=0.09,conf=0.8,maxlen=5))
rule=apriori(shopping,parameter=list(supp=0.2,conf=0.5,maxlen=5),appearance=list(rhs="Alcohol",default="lhs"))
inspect(head(sort(rule,by="support"),10))
inspect(head(sort(rule,by="confidence"),10))


#apriori Titanic
df=as.data.frame(Titanic) #32x5
Titan=NULL
for (i in 1:4)
	Titan=cbind(Titan,rep(as.character(df[,i]),df$Freq))
Titan=as.data.frame(Titan) #2201x4
names(Titan)=names(df)[1:4]
summary(Titan)
library(arules)
rule=apriori(Titan)
inspect(rule)
#refining and pruning rules
rule=apriori(Titan,parameter=list(minlen=2,supp=0.005,conf=0.8),appearance=list(rhs=c("Survived=No","Survived=Yes"),default="lhs"))
rulesort=sort(rule,by="lift")
inspect(rulesort)
subset.matrix=is.subset(rulesort,rulesort)
redundant=colSums(subset.matrix) > 1
which(redundant)
rulepruned=rulesort[!redundant]
inspect(rulepruned)
rule2=apriori(Titan, control = list(verbose=F),parameter = list(minlen=3, supp=0.002, conf=0.2),appearance =
 list(default="none", rhs=c("Survived=Yes"),lhs=c("Class=1st", "Class=2nd", "Class=3rd","Age=Child", "Age=Adult")))
rule2.sorted= sort(rule2, by="confidence")
inspect(rule2.sorted)
#Visualization
library(arulesViz)
plot(rulepruned)
plot(rulepruned,method="grouped") 
plot(rulepruned,method="graph",control=list(type="items"))
plot(rulepruned, method = "paracoord", control = list(reorder = TRUE))

# cspade TelRepair
library("arulesSequences")
repair=read_baskets("d:\\stella\\R\\TelRepair.txt",sep="\t",info=c("sequenceID","eventID"))
arulesSeq=cspade(repair,parameter = list(supp=0.2),control = list(verbose=T),tmpdir=tempdir())
summary(arulesSeq)
as(arulesSeq,"data.frame")



#Apriori iris
attach(iris)
SL=ordered(cut(Sepal.Length,breaks=4))
SW=ordered(cut(Sepal.Width,breaks=4))
PL=ordered(cut(Petal.Length,breaks=4))
PW=ordered(cut(Petal.Width,breaks=4))
iris2=data.frame(SL,SW,PL,PW,Species)
iris3=as(iris2,"transactions")
dim(iris3) #150 19
rules=apriori(iris3,parameter=list(supp=0.2,conf=0.6,target = "rules"),appearance=list(rhs="Species=setosa",default="lhs"))
summary(rules)
inspect(head(sort(rules,by="support"),n=100))

#Apriori Adult 48842x115
data(Adult)
inspect(Adult[1:4,])
rules=apriori(Adult,parameter=list(supp=0.5,conf = 0.9,target="rules"))
summary(rules)
inspect(head(sort(rules,by="support"),n=100))


