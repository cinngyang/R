### 巨量資料分析與應用 Using - R --------
### 05- 巨量資料分析與應用 Using - R - 分類(Cluster analysis) ----
# 東海大學資訊管理學系 姜自強博士

# 本章介紹 R 中各種分類技術的例子，包括k均值分類，
# k-medoids分類，層次聚類和基於密度的分類。 
# 前兩個部分演示如何使用k-means和k-medoids算法對 IRIS 數據進行分類。 
# 第三部分顯示了對相同數據進行分層聚類的示例。 
# 最後一節描述 基於密度的聚類和DBSCAN算法的思想，並展示瞭如何進行分類
# DBSCAN，然後用聚類模型標記新的數據。 

# Cluster analysis https://en.wikipedia.org/wiki/Cluster_analysis


### 5-1 k均值分類 (The k-Means Clustering) ------- 
# 本節展示鳶尾花(iris)資料集的k均值分類。
# 首先，我們從數據中刪除物種進行分類。 之後我們將函數kmeans（）應用於
# iris2，並將聚類結果存儲在kmeans.result中。 

# 本節介紹如何在包中使用函數kmeans()構建鳶尾花(iris)資料集的k均值分類
# 其中Sepal.Length，Sepal.Width，Petal.Length和Petal.Width被用來預測鳶尾花品種分類
# 在函數kmeans()構建分類，而 predict（）對新數據進行預測。

data(iris)
head(iris)

# 查看資料集的資料結構:
str(iris)
# 'data.frame':	150 obs. of  5 variables:
# $ Sepal.Length: num  5.1 4.9 4.7 4.6 5 5.4 4.6 5 4.4 4.9 ...
# $ Sepal.Width : num  3.5 3 3.2 3.1 3.6 3.9 3.4 3.4 2.9 3.1 ...
# $ Petal.Length: num  1.4 1.4 1.3 1.5 1.4 1.7 1.4 1.5 1.4 1.5 ...
# $ Petal.Width : num  0.2 0.2 0.2 0.2 0.2 0.4 0.3 0.2 0.2 0.1 ...
# $ Species     : Factor w/ 3 levels "setosa","versicolor",..: 1 1 1 1 1 1 1 1 1 1 ...

iris2 <- iris

# 首先，我們從數據中刪除物種進行分類。
iris2$Species <- NULL
head(iris2)
kmeans.result <- kmeans(iris2, 3)
(kmeans.result <- kmeans(iris2, 3))
# K-means clustering with 3 clusters of sizes 38, 62, 50
# 
# Cluster means:
#   Sepal.Length Sepal.Width Petal.Length Petal.Width
# 1     6.850000    3.073684     5.742105    2.071053
# 2     5.901613    2.748387     4.393548    1.433871
# 3     5.006000    3.428000     1.462000    0.246000
# 
# Clustering vector:
#  [1] 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3
# [43] 3 3 3 3 3 3 3 3 2 2 1 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 1 2 2 2 2 2 2
# [85] 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 1 2 1 1 1 1 2 1 1 1 1 1 1 2 2 1 1 1 1 2 1 2 1 2 1 1
# [127] 2 2 1 1 1 1 1 2 1 1 1 1 2 1 1 1 2 1 1 1 2 1 1 2
# 
# Within cluster sum of squares by cluster:
# [1] 23.87947 39.82097 15.15100
# (between_SS / total_SS =  88.4 %)
# 
# Available components:
#     
# [1] "cluster"      "centers"      "totss"        "withinss"     "tot.withinss"
# [6] "betweenss"    "size"         "iter"         "ifault"    

# 然後將聚類結果與品種（Species）進行比較以檢查是否相似對像被分組在一起。
names(kmeans.result)
# [1] "cluster"      "centers"   "totss"       "withinss"    "tot.withinss" "betweenss"   "size"        
# [8] "iter"         "ifault"   
kmeans.result$cluster
# [1] 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 2
# [52] 2 1 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 1 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 1 2
# [103] 1 1 1 1 2 1 1 1 1 1 1 2 2 1 1 1 1 2 1 2 1 2 1 1 2 2 1 1 1 1 1 2 1 1 1 1 2 1 1 1 2 1 1 1 2 1 1 2

table(iris$Species, kmeans.result$cluster)
#             1  2  3
# setosa      0  0 50
# versicolor  2 48  0
# virginica  36 14  0

# 以上結果表明cluster \ setosa“可以很容易地從其他簇中分離出來，而且
# 那些集群\ versicolor“和\ virginica”在很小程度上是相互重疊的。
# 接下來，繪製聚類及其中心圖。 請注意，有四個
# 數據中的尺寸，只有前兩個尺寸用於繪製下面的圖。
# 靠近綠色中心的一些黑點（星號）實際上更接近黑色中心
# 四維空間。 我們還需要知道，k均值聚類的結果可能會有所不同
# 從運行到運行，由於隨機選擇初始聚類中心。

plot(iris2[c("Sepal.Length", "Sepal.Width")], col = kmeans.result$cluster)
# plot cluster centers 繪製聚類及其中心點
kmeans.result$centers
#   Sepal.Length Sepal.Width Petal.Length Petal.Width
# 1     6.850000    3.073684     5.742105    2.071053
# 2     5.901613    2.748387     4.393548    1.433871
# 3     5.006000    3.428000     1.462000    0.246000
points(kmeans.result$centers[ ,c("Sepal.Length", "Sepal.Width")], col = 1:3,
             pch = 8, cex=3)

# 5-2 基於分類的離群值檢測 Outlier Detection by Clustering -------------
# 檢測異常值的另一種方法是聚類。 通過將數據分組到集群，這些數據不是
# 分配給任何群集被視為異常值。 例如，使用基於密度的聚類如
# DBSCAN [Ester et al。，1996]，如果物體連接到一個物體，則物體被分組到一個物體中
# 另一個人口稠密的地區。 因此，未分配給任何群集的對像是孤立的
# 從其他對象，被視為異常。 DBSCAN的一個例子基於密度的聚類。
# 我們還可以用k-means算法檢測異常值。 用k-means，數據被分割
# 通過將它們分配到最近的聚類中心而將它們分成k組。 之後，我們可以計算出來
# 每個對象與其集群中心之間的距離（或不相似度），並挑選最大的對象
# 距離作為異常值。 用虹膜數據中的k-means進行異常值檢測的一個例子

# remove species from the data to cluster
iris3 <- iris[ ,1:4]
kmeans.result2 <- kmeans(iris3, centers=3)
# cluster centers
kmeans.result2$centers
#   Sepal.Length Sepal.Width Petal.Length Petal.Width
# 1     6.850000    3.073684     5.742105    2.071053
# 2     5.006000    3.428000     1.462000    0.246000
# 3     5.901613    2.748387     4.393548    1.433871

# cluster IDs
kmeans.result2$cluster
# [1] 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3 3
# [51] 2 2 1 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 1 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2 2
# [101] 1 2 1 1 1 1 2 1 1 1 1 1 1 2 2 1 1 1 1 2 1 2 1 2 1 1 2 2 1 1 1 1 1 2 1 1 1 1 2 1 1 1 2 1 1 1 2 1 1 2

# calculate distances between objects and cluster centers
centers <- kmeans.result2$centers[kmeans.result2$cluster, ]
#   Sepal.Length Sepal.Width Petal.Length Petal.Width
# 3     5.006000    3.428000     1.462000    0.246000
# 3     5.006000    3.428000     1.462000    0.246000
# 3     5.006000    3.428000     1.462000    0.246000
# 3     5.006000    3.428000     1.462000    0.246000

distances <- sqrt(rowSums((iris3 - centers)^2))
head(distances)
# [1] 0.1413506 0.4476382 0.4171091 0.5253380 0.1886266 0.6770377

# pick top 5 largest distances
outliersTopFive <- order(distances, decreasing=T)[1:5]
outliersTopFive
# [1]  99  58  94  61 119

# who are outliers
print(outliersTopFive)

print(iris3[outliersTopFive, ])
#     Sepal.Length Sepal.Width Petal.Length Petal.Width
# 99           5.1         2.5          3.0         1.1
# 58           4.9         2.4          3.3         1.0
# 94           5.0         2.3          3.3         1.0
# 61           5.0         2.0          3.5         1.0
# 119          7.7         2.6          6.9         2.3

# plot clusters
plot(iris3[ ,c("Sepal.Length", "Sepal.Width")], pch="o",
        col=kmeans.result2$cluster, cex=1)
# plot cluster centers
points(kmeans.result2$centers[,c("Sepal.Length", "Sepal.Width")], col=1:3,
              pch=8, cex=3)
# plot outliers
# Cluster centers are labeled with asterisks and outliers with \+".
points(iris3[outliersTopFive, c("Sepal.Length", "Sepal.Width")], pch="+", col=4, cex=3)

# 一起來看看我們的資料分布囉!
# 基礎的plot函數可依參數的性質畫出不同的X-Y散佈圖、長條圖、盒狀圖、散佈圖矩陣：

#花萼長度(Sepal Length)與花萼寬度(Sepal Width) 散佈圖
plot(iris$Sepal.Length, iris$Sepal.Width) 
plot(iris$Sepal.Length, iris$Sepal.Width, col = iris$Species)

#品種類別(Species Class) 長條圖
plot(iris$Species)
plot(iris$Species, col = 2:4) 

#品種類別(Species Class)與花萼長度(Sepal Length) 盒鬚圖
plot(iris$Species, iris$Sepal.Length) 
plot(iris$Species, iris$Sepal.Length, col = 2:4) 

#散佈圖矩陣
plot(iris)
plot(iris, col = iris$Species)
pairs(iris, col = iris$Species)

#分別來看看各品種的長度散佈圖矩陣
attach(iris)
plot(Sepal.Length[Species=="setosa"],Petal.Length[Species=="setosa"], 
     pch=1 ,col="blue", xlim=c(4,8), ylim= c(0,8), 
     main="各品種的長度散佈圖", xlab= "SLen", ylab= "PLen")
points(Sepal.Length[Species=="virginica"], Petal.Length[Species== "virginica"],
       pch=3,col="green")
points(Sepal.Length[Species=="versicolor"], Petal.Length[Species== "versicolor"],
       pch=2,col="red")
legend(4,8,legend=c("setosa","versicolor","virginica"), col=c("blue","red","green"), pch=c(1,2,3))





install.packages("readr")
library(readr)
abalone<- read_csv("data/abalone.data", col_names =  FALSE)
View(abalone)
names(abalone) <- c("Sex","Length","Diameter","Height","WholeWeight", "ShuckedWeight",
"VisceraWeight", "ShellWeight", "Rings")

abalone2 <- abalone
abalone2$Rings <- NULL
(abalone2.result <- kmeans(abalone2[ , -1], 5))

abalone2$Sex  <- as.factor(abalone2$Sex)
(abalone2.result <- kmeans(abalone2, 3))

is.na(abalone2)
sum(is.na(abalone2))
summary(abalone2)

str(abalone2)
(abalone2.result <- kmeans(abalone2[ , -1], 3))
(abalone2.result <- kmeans(abalone2[ , -1], 4))
(abalone2.result <- kmeans(abalone2[ , -1], 5))
(abalone2.result <- kmeans(abalone2[ , -1], 6))
names(abalone2)
plot(abalone2[c("ShellWeight", "ShuckedWeight")], col = abalone2.result$cluster)
### 2,2 使用NbClust套組的NbClust函數 (決定分群的數目) -------
### 另外我們也亦可使用NbClust套組的NbClust函數，協助使用者決定分群的數目，程式碼如下：
library(NbClust)
# iris2=iris[,-5]
result=NbClust(abalone2[ , -1],distance="euclidean",min.nc=2,max.nc=6, method="kmeans", index="all")
result$Best.partition


library(fpc)

pamk.result=pamk(abalone2[ , -1])   #使用者不必決定分成幾組
pamk.result
