### 巨量資料分析與應用 Using - R --------
### 04- 巨量資料分析與應用 Using - R - 決策數與隨機森林(Decision Trees and Random Forest) ----
# 東海大學資訊管理學系 姜自強博士

# 本章介紹如何使用package套件 party，rpart 和 randomForest構建預測模型。
# https://archive.ics.uci.edu/ml/datasets/Abalone 
# Predict the age of abalone from physical measurements 從物理測量中預測鮑魚的年齡

# Data Set Information:
# Predicting the age of abalone from physical measurements. The age of abalone is determined by cutting the shell through the cone, staining it, and counting the number of rings through a microscope -- a boring and time-consuming task. Other measurements, which are easier to obtain, are used to predict the age. Further information, such as weather patterns and location (hence food availability) may be required to solve the problem. 
# 數據集信息：
# 從物理測量中預測鮑魚的年齡。 鮑魚的年齡取決於從錐體切割殼體，染色，並通過顯微鏡計數環的數量 - 這是一個無聊而費時的任務。 其他測量，這是更容易獲得，被用來預測年齡。 進一步的信息，如天氣模式和位置（因此食物的可用性）可能需要解決這個問題。

# Attribute Information:

# Given is the attribute name, attribute type, the measurement unit and a brief description. The number of rings is the value to predict: either as a continuous value or as a classification problem. 
# 
# Name / Data Type / Measurement Unit / Description 
# ----------------------------- 
# Sex / nominal / -- / M, F, and I (infant) 
# Length / continuous / mm / Longest shell measurement 
# Diameter	/ continuous / mm / perpendicular to length 
# Height / continuous / mm / with meat in shell 
# Whole weight / continuous / grams / whole abalone 
# Shucked weight / continuous	/ grams / weight of meat 
# Viscera weight / continuous / grams / gut weight (after bleeding) 
# Shell weight / continuous / grams / after being dried 
# Rings / integer / -- / +1.5 gives the age in years 
# 
# The readme file contains attribute statistics.

# 屬性信息：
# 
# 給定的是屬性名稱，屬性類型，度量單位和簡要描述。 環的數量是要預測的值：要么作為連續值，要么作為分類問題。
# 
# 名稱/     數據類型/   度量單位/   說明
# -----------------------------
# 性別/     名義/       - /         M，F和I（嬰兒）
# 長度/     連續/       毫米/       最長殼測量
# 直徑/     連續/       毫米/       垂直於長度
# 高度/     連續/       毫米/       外殼肉
# 總重量/   連續/       克/         整個鮑魚
# 肉的重量/ 連續/        克/        重量
# 內臟重量/ 連續/        克/        腸道重量（出血後）
# 外殼重量/ 連續/        克/        乾燥後
# 戒指/     整數/       - /         +1.5為年齡
# 
# 自述文件包含屬性統計信息。

## 資料輸入-----
library(readr)
abalone<- read_csv("abalone.data", col_names =  FALSE)
View(abalone)

# Name		        Data Type	Meas.	Description
# ----		        ---------	-----	-----------
# Sex		        nominal			    M, F, and I (infant)
# Length		    continuous	mm	    Longest shell measurement
# Diameter	        continuous	mm	    perpendicular to length
# Height		    continuous	mm	    with meat in shell
# Whole weight	    continuous	grams	whole abalone
# Shucked weight	continuous	grams	weight of meat
# Viscera weight	continuous	grams	gut weight (after bleeding)
# Shell weight	    continuous	grams	after being dried
# Rings		        integer			    +1.5 gives the age in years

abaloneBackUp <- abalone

names(abalone)
# [1] "X1" "X2" "X3" "X4" "X5" "X6" "X7" "X8" "X9"

names(abalone) <- c("Sex","Length","Diameter","Height","WholeWeight", "ShuckedWeight",
                    "VisceraWeight", "ShellWeight", "Rings")
names(abalone)
# [1] "Sex"           "Length"        "Diameter"      "Height"        "WholeWeight"   "ShuckedWeight"
# [7] "VisceraWeight" "ShellWeight"   "Rings" 

abaloneC <- abalone
names(abaloneC) <- c("性別","長度","直徑","高度","總重量", "肉的重量",
                    "內臟重量", "外殼重量", "環")
names(abaloneC)
# [1] "性別"     "長度"     "直徑"     "高度"     "總重量"   "肉的重量" "內臟重量" "外殼重量" "環"  

str(abalone)
# Classes ‘tbl_df’, ‘tbl’ and 'data.frame':	4177 obs. of  9 variables:
# $ Sex          : 性別     chr  "M" "M" "F" "M" ...
# $ Length       : 長度     num  0.455 0.35 0.53 0.44 0.33 0.425 0.53 0.545 0.475 0.55 ...
# $ Diameter     : 直徑     num  0.365 0.265 0.42 0.365 0.255 0.3 0.415 0.425 0.37 0.44 ...
# $ Height       : 高度     num  0.095 0.09 0.135 0.125 0.08 0.095 0.15 0.125 0.125 0.15 ...
# $ WholeWeight  : 總重量   num  0.514 0.226 0.677 0.516 0.205 ...
# $ ShuckedWeight: 肉的重量 num  0.2245 0.0995 0.2565 0.2155 0.0895 ...
# $ VisceraWeight: 內臟重量 num  0.101 0.0485 0.1415 0.114 0.0395 ...
# $ ShellWeight  : 外殼重量 num  0.15 0.07 0.21 0.155 0.055 0.12 0.33 0.26 0.165 0.32 ...
# $ Rings        : 環 int  15 7 9 10 7 8 20 16 9 19 ...  年齡 = 環 + 1.5

### dplyr 資料整理工具套件 dplyr ---------
install.packages("dplyr")
library(dplyr)

## dplyr - select() 選取數值型變數出來! -------
abaloneNumType <- select(abalone, Length: ShellWeight)
names(abaloneNumType)
# [1] "Length"        "Diameter"      "Height"        "WholeWeight"   "ShuckedWeight" "VisceraWeight"
# [7] "ShellWeight" 

## 選擇隨機 N 行 Selecting Random N Rows ------------
sample_n(abalone, 3, replace = TRUE)
#  A tibble: 3 x 9
#     Sex Length Diameter Height WholeWeight ShuckedWeight VisceraWeight ShellWeight Rings
#   <chr>  <dbl>    <dbl>  <dbl>       <dbl>         <dbl>         <dbl>       <dbl> <int>
# 1     M  0.635    0.475  0.170      1.1935        0.5205        0.2695      0.3665    10
# 2     I  0.560    0.445  0.165      1.0285        0.4535        0.2530      0.2750    11
# 3     M  0.560    0.440  0.140      0.9710        0.4430        0.2045      0.2650    14

### Selecting Random Fraction(分數或比例) of Rows -----
abaloneTestData <- sample_frac(abalone, 0.3)
dim(abaloneTestData)
# [1] 1253    9

## 假設你需要子集數據。 過濾橫列(觀測值)資料 Filter Rows ------
(abaloneFilter01 = filter(abalone, Sex == "I"))
(abaloneFilter02 = filter(abalone, WholeWeight >= mean(WholeWeight) ))
(abaloneFilter03 = filter(abalone, Rings >= max(Rings) ))

## 總結選定的變量 Summarize selected variables  -----
summarise(abalone, WholeWeight_mean = mean(WholeWeight), Rings_med=median(Rings), count = n())
#   WholeWeight_mean Rings_med count
#              <dbl>     <int> <int>
# 1        0.8287422         9  4177

## 創建一個新變量 Create a new variable --------------
abaloneMutate <- mutate(abalone, WholeWeightVsRings = WholeWeight / Rings)
names(abaloneMutate)
# [1] "Sex"                "Length"             "Diameter"           "Height"            
# [5] "WholeWeight"        "ShuckedWeight"      "VisceraWeight"      "ShellWeight"       
# [9] "Rings"              "WholeWeightVsRings"

mean(abaloneMutate$WholeWeightVsRings)
# [1] 0.08109457

## 總結，分組和排序 Summarize, Group and Sort Together  --------------
abaloneMutate %>% group_by(Sex) %>% summarise(count = n(), WholeWeightMean = mean(WholeWeight))
#     Sex count WholeWeightMean
#   <chr> <int>           <dbl>
# 1     F  1307       1.0465321
# 2     I  1342       0.4313625
# 3     M  1528       0.9914594

abaloneMutate %>% group_by(Sex, Rings) %>% summarise(count = n(), WholeWeightMean = mean(WholeWeight))
# A tibble: 68 x 4
# Groups:   Sex [?]
# Sex Rings count WholeWeightMean
# <chr> <int> <int>           <dbl>
# 1     F     5     4       0.1622500
# 2     F     6    16       0.5595938
# 3     F     7    44       0.5927273
# 4     F     8   122       0.8122787
# 5     F     9   238       0.9820504
# 6     F    10   248       1.0557056
# 7     F    11   200       1.2165125
# 8     F    12   128       1.1142422
# 9     F    13    88       1.0742955
# 10     F    14    56       1.1477768
# # ... with 58 more rows

## 數值型各變數分布圖 --------
pairs(abaloneNumType)

pairs(abalone[ ,2:8])

abalone$Sex <- as.factor(abalone$Sex)

pairs(abalone[ ,2:8], col = abalone$Sex )

# 一起來看看我們的資料分布囉!
# 基礎的plot函數可依參數的性質畫出不同的X-Y散佈圖、長條圖、盒狀圖、散佈圖矩陣：

#直徑(Diameter)與總重量(WholeWeight) 散佈圖
plot(abalone$Diameter, abalone$WholeWeight) 
plot(abalone$Diameter, abalone$WholeWeight, col = abalone$Sex)

### 4-1 使用package套件 party -函數ctree建立決策樹(Decision Trees with Package party with ctree()) ------- 
# 本節介紹如何在包中使用函數ctree（）構建鮑魚(abalone)資料集的決策樹
# 其中Sepal.Length，Sepal.Width，Petal.Length和Petal.Width被用來預測鮑魚
# 在函數ctree（）構建決策樹，而 predict（）對新數據進行預測。
# 在建模之前，鳶尾花(iris)資料集被分成兩個子集：訓練（70％）和測試（30％）。
# 隨機種子設置為以下的固定值，以使結果可重現。

head(abalone)
pairs(abalone[ ,-1])
pairs(abalone[ ,-1], col = abalone$Sex) ## error
str(abalone)
# Classes ‘tbl_df’, ‘tbl’ and 'data.frame':	4177 obs. of  9 variables:
# $ Sex          : chr  "M" "M" "F" "M" ...
# $ Length       : num  0.455 0.35 0.53 0.44 0.33 0.425 0.53 0.545 0.475 0.55 ...
# $ Diameter     : num  0.365 0.265 0.42 0.365 0.255 0.3 0.415 0.425 0.37 0.44 ...
# $ Height       : num  0.095 0.09 0.135 0.125 0.08 0.095 0.15 0.125 0.125 0.15 ...
# $ WholeWeight  : num  0.514 0.226 0.677 0.516 0.205 ...
# $ ShuckedWeight: num  0.2245 0.0995 0.2565 0.2155 0.0895 ...
# $ VisceraWeight: num  0.101 0.0485 0.1415 0.114 0.0395 ...
# $ ShellWeight  : num  0.15 0.07 0.21 0.155 0.055 0.12 0.33 0.26 0.165 0.32 ...
# $ Rings        : int  15 7 9 10 7 8 20 16 9 19 ...
abalone$Sex <- as.factor(abalone$Sex)
abaloneC$性別 <- as.factor(abaloneC$性別)

# 查看資料集的資料結構:
str(abalone)
# Classes ‘tbl_df’, ‘tbl’ and 'data.frame':	4177 obs. of  9 variables:
# $ Sex          : Factor w/ 3 levels "F","I","M": 3 3 1 3 2 2 1 1 3 1 ...
# $ Length       : num  0.455 0.35 0.53 0.44 0.33 0.425 0.53 0.545 0.475 0.55 ...
# $ Diameter     : num  0.365 0.265 0.42 0.365 0.255 0.3 0.415 0.425 0.37 0.44 ...
# $ Height       : num  0.095 0.09 0.135 0.125 0.08 0.095 0.15 0.125 0.125 0.15 ...
# $ WholeWeight  : num  0.514 0.226 0.677 0.516 0.205 ...
# $ ShuckedWeight: num  0.2245 0.0995 0.2565 0.2155 0.0895 ...
# $ VisceraWeight: num  0.101 0.0485 0.1415 0.114 0.0395 ...
# $ ShellWeight  : num  0.15 0.07 0.21 0.155 0.055 0.12 0.33 0.26 0.165 0.32 ...
# $ Rings        : int  15 7 9 10 7 8 20 16 9 19 ...

summary(abalone)
# Sex          Length         Diameter          Height        WholeWeight    
# F:1307   Min.   :0.075   Min.   :0.0550   Min.   :0.0000   Min.   :0.0020  
# I:1342   1st Qu.:0.450   1st Qu.:0.3500   1st Qu.:0.1150   1st Qu.:0.4415  
# M:1528   Median :0.545   Median :0.4250   Median :0.1400   Median :0.7995  
#          Mean   :0.524   Mean   :0.4079   Mean   :0.1395   Mean   :0.8287  
#          3rd Qu.:0.615   3rd Qu.:0.4800   3rd Qu.:0.1650   3rd Qu.:1.1530  
#          Max.   :0.815   Max.   :0.6500   Max.   :1.1300   Max.   :2.8255  
# ShuckedWeight    VisceraWeight     ShellWeight         Rings       
# Min.   :0.0010   Min.   :0.0005   Min.   :0.0015   Min.   : 1.000  
# 1st Qu.:0.1860   1st Qu.:0.0935   1st Qu.:0.1300   1st Qu.: 8.000  
# Median :0.3360   Median :0.1710   Median :0.2340   Median : 9.000  
# Mean   :0.3594   Mean   :0.1806   Mean   :0.2388   Mean   : 9.934  
# 3rd Qu.:0.5020   3rd Qu.:0.2530   3rd Qu.:0.3290   3rd Qu.:11.000  
# Max.   :1.4880   Max.   :0.7600   Max.   :1.0050   Max.   :29.000 

# 隨機種子設置為以下的固定值，以使結果可重現。
set.seed(1234)

# 在建模之前，鳶尾花(iris)資料集被分成兩個子集：訓練（70％）和測試（30％）。
index <- sample(2, nrow(abalone), replace=TRUE, prob=c(0.7, 0.3))
index

# 驗證取樣百分比!
sum(index == 1) / length(index)  # [1] 0.7466667
sum(index == 2) / length(index)  # [1] 0.2533333

## sample() 取樣函數
?sample
# Random Samples and Permutations
# Description
# sample takes a sample of the specified size from the elements of x using either with or without replacement.
# Usage
# sample(x, size, replace = FALSE, prob = NULL)

# 訓練（70％）和測試（30％）
trainData <- abalone[index==1, ]
testData <- abalone[index==2, ]

trainDataC <- abaloneC[index==1, ]
testDataC <- abaloneC[index==2, ]

library(party)
myFormula <- Rings ~ .
abalone_ctree <- ctree(myFormula, data = trainData)

myFormulaC <- 年齡 ~ .
abalone_ctreeC <- ctree(myFormulaC, data = trainDataC)

attributes(abalone_ctree)

# check the prediction
table(predict(abalone_ctree), trainData$Rings)


print(abalone_ctree)

plot(abalone_ctree)

plot(abalone_ctree, type="simple")

print(abalone_ctreeC)

plot(abalone_ctreeC)

plot(abalone_ctreeC, type="simple")


# predict on test data
testPred <- predict(abalone_ctree, newdata = testData)
testPred
table(testPred, testData$Rings)
# 
# testPred     setosa versicolor virginica
#   setosa         10          0         0
#   versicolor      0         12         2
#   virginica       0          0        14

?ctree  # ************************************************************************************
# Conditional Inference Trees
# 
# Description
# 
# Recursive partitioning for continuous, censored, ordered, nominal and multivariate response variables in a conditional inference framework.
# 
# Usage
# 
# ctree(formula, data, subset = NULL, weights = NULL, 
#       controls = ctree_control(), xtrafo = ptrafo, ytrafo = ptrafo, 
#       scores = NULL)

# samples


set.seed(290875)

### regression
airq <- subset(airquality, !is.na(Ozone))
airct <- ctree(Ozone ~ ., data = airq, 
               controls = ctree_control(maxsurrogate = 3))
airct
plot(airct)
mean((airq$Ozone - predict(airct))^2)
### extract terminal node ID, two ways
all.equal(predict(airct, type = "node"), where(airct))

### classification
irisct <- ctree(Species ~ .,data = iris)
irisct
plot(irisct)
table(predict(irisct), iris$Species)

### estimated class probabilities, a list
tr <- treeresponse(irisct, newdata = iris[1:10,])

### ordinal regression
data("mammoexp", package = "TH.data")
mammoct <- ctree(ME ~ ., data = mammoexp) 
plot(mammoct)

### estimated class probabilities
treeresponse(mammoct, newdata = mammoexp[1:10,])

### survival analysis
if (require("TH.data") && require("survival")) {
    data("GBSG2", package = "TH.data")
    GBSG2ct <- ctree(Surv(time, cens) ~ .,data = GBSG2)
    plot(GBSG2ct)
    treeresponse(GBSG2ct, newdata = GBSG2[1:2,])        
}
# End of ?ctree() ****************************************************************************

## ctree() 延伸閱讀:
# Conditional Inference Trees 
# https://www.rdocumentation.org/packages/partykit/versions/1.1-1/topics/ctree

### 4-2 使用package套件 rpart 建立決策樹 ------
library(rpart)

### 4-2-1 鳶尾花(iris)資料集 使用package套件 rpart 建立決策樹  ------
data(iris)
head(iris)
pairs(iris, col = iris$Species)

# 查看資料集的資料結構:
str(iris)
# 'data.frame':	150 obs. of  5 variables:
# $ Sepal.Length: num  5.1 4.9 4.7 4.6 5 5.4 4.6 5 4.4 4.9 ...
# $ Sepal.Width : num  3.5 3 3.2 3.1 3.6 3.9 3.4 3.4 2.9 3.1 ...
# $ Petal.Length: num  1.4 1.4 1.3 1.5 1.4 1.7 1.4 1.5 1.4 1.5 ...
# $ Petal.Width : num  0.2 0.2 0.2 0.2 0.2 0.4 0.3 0.2 0.2 0.1 ...
# $ Species     : Factor w/ 3 levels "setosa","versicolor",..: 1 1 1 1 1 1 1 1 1 1 ...

# 隨機種子設置為以下的固定值，以使結果可重現。
set.seed(1234)

# 在建模之前，鳶尾花(iris)資料集被分成兩個子集：訓練（70％）和測試（30％）。
index <- sample(2, nrow(iris), replace=TRUE, prob=c(0.7, 0.3))
index

# 驗證取樣百分比!
sum(index == 1) / length(index)  # [1] 0.7466667
sum(index == 2) / length(index)  # [1] 0.2533333

# 訓練（70％）和測試（30％）
trainData <- iris[index==1, ]
testData <- iris[index==2, ]

myFormula <- Species ~ Sepal.Length + Sepal.Width + Petal.Length + Petal.Width
iris_rpart <- rpart(myFormula, data = trainData,
                       control = rpart.control(minsplit = 10))
attributes(iris_rpart)
# $names
# [1] "frame"               "where"               "call"                "terms"              
# [5] "cptable"             "method"              "parms"               "control"            
# [9] "functions"           "numresp"             "splits"              "variable.importance"
# [13] "y"                   "ordered"            
# 
# $xlevels
# named list()
# 
# $ylevels
# [1] "setosa"     "versicolor" "virginica" 
# 
# $class
# [1] "rpart"

print(iris_rpart$cptable)
#           CP nsplit  rel error     xerror       xstd
# 1 0.52777778      0 1.00000000 1.15277778 0.06438675
# 2 0.41666667      1 0.47222222 0.55555556 0.07042952
# 3 0.01388889      2 0.05555556 0.08333333 0.03309688
# 4 0.01000000      3 0.04166667 0.08333333 0.03309688

print(iris_rpart)
# n= 112 
# 
# node), split, n, loss, yval, (yprob)
# * denotes terminal node
# 
# 1) root 112 72 setosa (0.35714286 0.33928571 0.30357143)  
#   2) Petal.Length< 2.45 40  0 setosa (1.00000000 0.00000000 0.00000000) *
#   3) Petal.Length>=2.45 72 34 versicolor (0.00000000 0.52777778 0.47222222)  
#     6) Petal.Width< 1.75 40  3 versicolor (0.00000000 0.92500000 0.07500000)  
#      12) Petal.Length< 5.05 37  1 versicolor (0.00000000 0.97297297 0.02702703) *
#      13) Petal.Length>=5.05 3  1 virginica (0.00000000 0.33333333 0.66666667) *
#     7) Petal.Width>=1.75 32  1 virginica (0.00000000 0.03125000 0.96875000) *

plot(iris_rpart)
text(iris_rpart, use.n = T)

opt <- which.min(iris_rpart$cptable[,"xerror"])
cp <- iris_rpart$cptable[opt, "CP"]
iris_prune <- prune(iris_rpart, cp = cp)
print(iris_prune)

plot(iris_prune)
text(iris_prune, use.n=T)

testPred <- predict(iris_rpart, newdata = testData)
testPred
table(testPred, testData$Species)  ### error
# Error in table(testPred, testData$Species) : 
# all arguments must have the same length

### 4-2-2 bodyfat 身體脂肪資料集 使用package套件 rpart 建立決策樹  ------
# 在本節中使用package套件 rpart 來構建 bodyfat 身體脂肪上的決策樹數據。 
# 函數rpart（）用於構建決策樹，並選擇具有最小預測誤差的樹。 
# 之後，它被應用於新的數據用函數 predict（）進行預測。
# 首先，我們加載 bodyfat 身體脂肪數據，並看看它。

data("bodyfat", package = "TH.data")
dim(bodyfat)
# [1] 71 10

attributes(bodyfat)
# $names
# [1] "age"          "DEXfat"       "waistcirc"    "hipcirc"      "elbowbreadth" "kneebreadth" 
# [7] "anthro3a"     "anthro3b"     "anthro3c"     "anthro4"     
# 
# $row.names
# [1] "47"  "48"  "49"  "50"  "51"  "52"  "53"  "54"  "55"  "56"  "57"  "58"  "59"  "60"  "61"  "62" 
# [17] "63"  "64"  "65"  "66"  "67"  "68"  "69"  "70"  "71"  "72"  "73"  "74"  "75"  "76"  "77"  "78" 
# [33] "79"  "80"  "81"  "82"  "83"  "84"  "85"  "86"  "87"  "88"  "89"  "90"  "91"  "92"  "93"  "94" 
# [49] "95"  "96"  "97"  "98"  "99"  "100" "101" "102" "103" "104" "105" "106" "107" "108" "109" "110"
# [65] "111" "112" "113" "114" "115" "116" "117"
# 
# $class
# [1] "data.frame"


bodyfat[1:5,]
#    age DEXfat waistcirc hipcirc elbowbreadth kneebreadth anthro3a anthro3b anthro3c anthro4
# 47  57  41.68     100.0   112.0          7.1         9.4     4.42     4.95     4.50    6.13
# 48  65  43.29      99.5   116.5          6.5         8.9     4.63     5.01     4.48    6.37
# 49  59  35.41      96.0   108.5          6.2         8.9     4.12     4.74     4.60    5.82
# 50  58  22.79      72.0    96.5          6.1         9.2     4.03     4.48     3.91    5.66
# 51  60  36.42      89.5   100.5          7.1        10.0     4.24     4.68     4.15    5.91

row.names(bodyfat)

# 接下來將數據分成訓練和測試子集，並且在訓練上構建決策樹數據。

set.seed(1234)
index <- sample(2, nrow(bodyfat), replace=TRUE, prob=c(0.7, 0.3))
bodyfat.train <- bodyfat[index == 1, ]
bodyfat.test <- bodyfat[index == 2, ]

# train a decision tree
library(rpart)
myFormula <- DEXfat ~ age + waistcirc + hipcirc + elbowbreadth + kneebreadth
bodyfat_rpart <- rpart(myFormula, data = bodyfat.train,
                          control = rpart.control(minsplit = 10))
attributes(bodyfat_rpart)
# $names
# [1] "frame"               "where"               "call"                "terms"              
# [5] "cptable"             "method"              "parms"               "control"            
# [9] "functions"           "numresp"             "splits"              "variable.importance"
# [13] "y"                   "ordered"            
# 
# $xlevels
# named list()

print(bodyfat_rpart$cptable)
#           CP nsplit  rel error    xerror       xstd
# 1 0.67272638      0 1.00000000 1.0194546 0.18724382
# 2 0.09390665      1 0.32727362 0.4415438 0.10853044
# 3 0.06037503      2 0.23336696 0.4271241 0.09362895
# 4 0.03420446      3 0.17299193 0.3842206 0.09030539
# 5 0.01708278      4 0.13878747 0.3038187 0.07295556
# 6 0.01695763      5 0.12170469 0.2739808 0.06599642
# 7 0.01007079      6 0.10474706 0.2693702 0.06613618
# 8 0.01000000      7 0.09467627 0.2695358 0.06620732

print(bodyfat_rpart)
# n= 56 
# 
# node), split, n, deviance, yval
# * denotes terminal node
# 
# 1) root 56 7265.0290000 30.94589  
#   2) waistcirc< 88.4 31  960.5381000 22.55645  
#     4) hipcirc< 96.25 14  222.2648000 18.41143  
#       8) age< 60.5 9   66.8809600 16.19222 *
#       9) age>=60.5 5   31.2769200 22.40600 *
#     5) hipcirc>=96.25 17  299.6470000 25.97000  
#      10) waistcirc< 77.75 6   30.7345500 22.32500 *
#      11) waistcirc>=77.75 11  145.7148000 27.95818  
#        22) hipcirc< 99.5 3    0.2568667 23.74667 *
#        23) hipcirc>=99.5 8   72.2933500 29.53750 *
#   3) waistcirc>=88.4 25 1417.1140000 41.34880  
#     6) waistcirc< 104.75 18  330.5792000 38.09111  
#      12) hipcirc< 109.9 9   68.9996200 34.37556 *
#      13) hipcirc>=109.9 9   13.0832000 41.80667 *
#     7) waistcirc>=104.75 7  404.3004000 49.72571 *

plot(bodyfat_rpart)
text(bodyfat_rpart, use.n=T)

opt <- which.min(bodyfat_rpart$cptable[,"xerror"])
opt
# 7 
# 7
cp <- bodyfat_rpart$cptable[opt, "CP"]
cp
# [1] 0.01007079


bodyfat_prune <- prune(bodyfat_rpart, cp = cp)

print(bodyfat_prune)

plot(bodyfat_prune)
text(bodyfat_prune, use.n=T)

# 之後，使用選擇的樹進行預測，並對預測值進行比較
# 與實際的標籤。 在下面的代碼中，函數abline（）繪製一條對角線。 
# 預期一個好的模型與他們的實際值相等或非常接近，即大多數點應該在對角線上或靠近對角線。
DEXfat_pred <- predict(bodyfat_prune, newdata=bodyfat.test)

xlim <- range(bodyfat$DEXfat)

plot(DEXfat_pred ~ DEXfat, data=bodyfat.test, xlab="Observed",
       ylab="Predicted", ylim=xlim, xlim=xlim)

abline(a=0, b=1, col = "red")

?rpart
# Recursive Partitioning and Regression Trees *********************************************
fit <- rpart(Kyphosis ~ Age + Number + Start, data = kyphosis)
fit2 <- rpart(Kyphosis ~ Age + Number + Start, data = kyphosis,
              parms = list(prior = c(.65,.35), split = "information"))
fit3 <- rpart(Kyphosis ~ Age + Number + Start, data = kyphosis,
              control = rpart.control(cp = 0.05))
par(mfrow = c(1,2), xpd = NA) # otherwise on some devices the text is clipped
plot(fit)
text(fit, use.n = TRUE)
plot(fit2)
text(fit2, use.n = TRUE)
# End of Recursive Partitioning and Regression Trees **************************************

# 延伸閱讀:
# http://www.cc.ntu.edu.tw/chinese/epaper/0031/20141220_3105.html

### 4-3 隨機森林 Random Forest -----------------
# 套件 randomForest [Liaw和Wiener]用於構建一個預測模型
# 功能有兩個限制
# randomForest（）。 首先，它不能處理缺少值的數據，用戶必須對數據進行歸併
# 然後餵給他們進入功能。 其次，最多有32個的限制
# 每個分類屬性的級別。 超過32個級別的屬性必須進行轉換
# 先使用randomForest（）。
# 構建隨機森林的另一種方法是使用package party中的函數cforest（）
# 這不限於上述的最高水平。 但是，一般來說，是絕對的
# 具有更多級別的變量將使其需要更多的內存，並花費更長的時間來構建一個
# 隨機森林。
# 再次，IRIS數據首先被分成兩個子集：訓練（70％）和測試（30％）。

index <- sample(2, nrow(iris), replace=TRUE, prob=c(0.7, 0.3))
trainData <- iris[index == 1, ]
testData <- iris[index == 2, ]

library(randomForest)

# \Species ~ .", which means to predict Species with all other variables in the data.

rf <- randomForest(Species ~ ., data=trainData, ntree=100, proximity=TRUE)
table(predict(rf), trainData$Species)
#            setosa versicolor virginica
# setosa         31          0         0
# versicolor      0         31         2
# virginica       0          1        40

print(rf)
# Call:
#     randomForest(formula = Species ~ ., data = trainData, ntree = 100,      proximity = TRUE) 
# Type of random forest: classification
# Number of trees: 100
# No. of variables tried at each split: 2
# 
# OOB estimate of  error rate: 2.86%
# Confusion matrix:
#            setosa versicolor virginica class.error
# setosa         31          0         0  0.00000000
# versicolor      0         31         1  0.03125000
# virginica       0          2        40  0.04761905

attributes(rf)
# $names
# [1] "call"            "type"            "predicted"       "err.rate"        "confusion"       "votes"          
# [7] "oob.times"       "classes"         "importance"      "importanceSD"    "localImportance" "proximity"      
# [13] "ntree"           "mtry"            "forest"          "y"               "test"            "inbag"          
# [19] "terms"          
# 
# $class
# [1] "randomForest.formula" "randomForest" 

# 之後，我們繪製出各種樹的錯誤率。
plot(rf)

# 重要的變數
#The importance of variables can be obtained with functions importance() and varImpPlot().
importance(rf)
# MeanDecreaseGini
# Sepal.Length         8.585560
# Sepal.Width          1.246064
# Petal.Length        28.442050
# Petal.Width         30.425898

varImpPlot(rf)

# Finally, the built random forest is tested on test data, and the result is checked with functions
# table() and margin(). The margin of a data point is as the proportion of votes for the correct
# class minus maximum proportion of votes for other classes. Generally speaking, positive margin means correct classification.
# 最後，在測試數據上測試構建的隨機森林，並使用函數table（）和margin（）檢查結果。 數據點的邊際是正確類別的投票的比例減去其他類別的最大比例。 一般來說，積極的意味著正確的分類。

irisPred <- predict(rf, newdata=testData)
table(irisPred, testData$Species)
# irisPred     setosa versicolor virginica
#   setosa         19          0         0
#   versicolor      0         16         1
#   virginica       0          2         7

plot(margin(rf, testData$Species))
