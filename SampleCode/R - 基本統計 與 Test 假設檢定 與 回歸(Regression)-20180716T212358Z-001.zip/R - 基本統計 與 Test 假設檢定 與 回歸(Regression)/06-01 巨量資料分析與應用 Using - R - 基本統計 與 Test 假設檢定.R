# ---
# title: "『R - 基本統計 與 Test 假設檢定』"
# author: <p align="right">東海大學資訊管理系（所）姜自強助理教授</p>
# ---
install.packages("ggplot2")
require(ggplot2)
# 我們用  GGally  套件中的  ggpairs  函數來繪圖
install.packages("GGally")
library(GGally)
# 載入reshape套件以溶化資料
install.packages("reshape2")
require(reshape2)
# 載入scales套件以增添繪圖功能
install.packages("scales")
require(scales)

install.packages("plyr")
require(plyr)

install.packages("dplyr")
require(dplyr)

# 基本統計
# * 統計學最常計算的數字包括了期望值、變異數、相關係數和 t 檢定。
# * 它們在 R 中所代表的函數各為 mean、var、cor 和 t.test。

### 1. 摘要統計(Summary Statistics) ------------

x <- sample(x = 1:100, size = 100, replace = TRUE)
x

# 很多人對統計的第一印象就是平均數  (average，或更正統的稱呼  mean)。
mean(x)
# 複製x
y <- x
# 用sample隨機挑選20個元素, 把值設為NA
xNA <- sample(x = 1:100, size = 20, replace = FALSE)
#  [1] 57 35 74 34 91 55 73 95 60 45 18 23 67 83 13 20  7 10 16 71  << 隨機挑選20個元素

y[xNA]

y[xNA] <- NA

y[xNA]

y
# 計算平均值非常簡單，不過用於統計應用，就要考慮資料含有遺失值的情況。
# mean 預設它只要遇到一個 NA 值，就直接回傳 NA 值作為結果，避免產生一些誤導性的訊息。
# 若要在計算平均值之前把 NA 值移除掉，可以設 na.rm 為 TRUE。
mean(y)
# [1] NA
mean(y, na.rm = TRUE)

# 若要對一組數字計算加權平均值，可以用  weighted.mean  函數。這函數的引數分別為該組數字的  vector  和權重的  vector，它也接受一個非必要的引數  na.rm。

grades <- c(95, 72, 87, 66)
weights <- c(1/2, 1/4, 1/8, 1/8)
mean(grades)
sum(weights)
weighted.mean(x = grades, w = weights)

sd(grades)
# [1] 13.34166

# 2. 變異數 -變異數即在量測所有資料到平均數的平均距離 --------------
# * 變異數:(https://zh.wikipedia.org/wiki/%E6%96%B9%E5%B7%AE)
# * 另一個很重要的統計量為變異數，計算變異數(variance)
# * 變異數即在量測所有資料到平均數的平均距離。一個很自然
# * 會被想到用來量測資料分散程度之指標值為平均絕對離差。
# * 但絕對值在代數運算上較麻煩，因此將絕對值以平方來替代
# * 變異數會因資料中少數幾筆特別大或特別小的值，使變異數
# * 變得特別大。

x
var(x)

# ---------------------------------------------------------- #
# 我們在 R 中手動計算來驗證這公式。
# 公式  http://estat.ncku.edu.tw/topic/desc_stat/base/variance.html
var(x)
sum((x - mean(x))^2)/(length(x) - 1)


# 3. 標準差 (standard deviation) -------------
# 標準差是一種表示分散程度的統計觀念。標準差已廣泛運用在股票以及共同基金投資風險的衡量上，主要是根據基金凈值於一段時間內波動的情況計算而來的。一般而言，標準差愈大，表示凈值的漲跌較劇烈，風險程度也較大。實務的運作上，可進一步運用單位風險報酬率的概念，同時將報酬率的風險因素考慮在內。所謂單位風險報酬率是指衡量投資人每承擔 一單位的風險，所能得到的報酬，以夏普指數最常為投資人運用。
# 
# 標準差是一組數值自平均值分散開來的程度的一種測量觀念。一個較大的標準差，代表大部分的數值和其平均值之間差異較大；一個較小的標準差，代表這些數值較接近平均值。
# 
# 例如，兩組數的集合 {0, 5, 9, 14} 和 {5, 6, 8, 9} 其平均值都是 7 ，但第二個集合具有較小的標準差。
# 
# 標準差可以當作不確定性的一種測量。例如在物理科學中，做重覆性測量時，測量數值集合的標準差代表這些測量的精確度。當要決定測量值是否符合預測值，測量值的標準差占有決定性重要角色：如果測量平均值與預測值相差太遠（同時與標準差數值做比較），則認為測量值與預測值互相矛盾。這很容易理解，因為值都落在一定數值範圍之外，可以合理推論預測值是否正確。

# * 標準差可由變異數開根號取得，在 R 中可以用 sd 來計算。
# * https://zh.wikipedia.org/wiki/%E6%A8%99%E6%BA%96%E5%B7%AE


sqrt(var(x))
#[1] 29.65548
sd(x)
#[1] 29.65548
sd(y)
#[1] NA
sd(y, na.rm = TRUE)
#[1] 29.85086

a <- c(0, 5, 9, 14)
b <- c(5, 6, 8, 9)
a
b

(sd(a))  # [1] 5.944185
(sd(b))  # [1] 1.825742

# 其他函數
min(x)
max(x)
median(x)  #中位數
min(y)
min(y, na.rm = TRUE)

# ---------------------------------------------------------- #
# summary  函數可以同時計算平均值、極小值、極大值和中位數。對此函數，若資料包含  NA  值會自動被移除掉。
summary(x)
summary(y)
# ---------------------------------------------------------- #
# 這摘要表還包括了第一和第三個四分位數(quartile)或第  25  和  75  個百分位數 (percentile)。
# 分位數意指其在一組數字裡，該組有某個百分比的數字是低於該分位數的。

# 計算第25和75百分位數
quantile(x, probs = c(0.25, 0.75))
#  25%   75% 
#20.75 71.25  # 分位數意指其在一組數字裡，該組有某個百分比的數字是低於該分位數的。 

# 也對y計算同樣的統計量
# quantile(y, probs = c(0.25, 0.75))

# 這次設na.rm=TRUE
quantile(y, probs = c(0.25, 0.75), na.rm = TRUE)

# 計算其它分位數
quantile(x, probs = c(0.1, 0.25, 0.5, 0.75, 0.99))


# 4. 相關係數(correlation)和共變異數(covariace) ------
# 相關係數(correlation): 
# * (https://zh.wikipedia.org/wiki/%E7%9B%B8%E5%85%B3)
# * 在機率論和統計學中相關（Correlation，或稱相關係數或關聯繫數）顯示兩個隨機變量之間線性關係的強度和方向。
# * 在統計學中，相關的意義是用來衡量兩個變量相對於其相互獨立的距離。
# * 當我們資料多於一個變數時候，顯示兩個隨機變量之間線性關係的強度和方向。
# * 檢測關係最直接的兩個方法為使用相關係數和共變異數。

# 我們以  ggplot2  套件中的 economics 資料來示範這兩個方法的概念。

require(ggplot2)
data(economics)
head(economics)
# A tibble: 6 x 6
#         date   pce    pop psavert uempmed unemploy
#       <date> <dbl>  <int>   <dbl>   <dbl>    <int>
# 1 1967-07-01 507.4 198712    12.5     4.5     2944
# 2 1967-08-01 510.5 198911    12.5     4.7     2945
# 3 1967-09-01 516.3 199113    11.7     4.6     2958
# 4 1967-10-01 512.9 199311    12.5     4.9     3143
# 5 1967-11-01 518.1 199498    12.5     4.7     3066
# 6 1967-12-01 525.8 199657    12.1     4.8     3018
str(economics)
# Classes ‘tbl_df’, ‘tbl’ and 'data.frame':	574 obs. of  6 variables:
# $ date    : Date, format: "1967-07-01" "1967-08-01" "1967-09-01" "1967-10-01" ...
# $ pce     : num  507 510 516 513 518 ...
# $ pop     : int  198712 198911 199113 199311 199498 199657 199808 199920 200056 200208 ...
# $ psavert : num  12.5 12.5 11.7 12.5 12.5 12.1 11.7 12.2 11.6 12.2 ...
# $ uempmed : num  4.5 4.7 4.6 4.9 4.7 4.8 5.1 4.5 4.1 4.6 ...
# $ unemploy: int  2944 2945 2958 3143 3066 3018 2878 3001 2877 2709 ...
summary(economics)
#      date                 pce               pop            psavert          uempmed         unemploy    
# Min.   :1967-07-01   Min.   :  507.4   Min.   :198712   Min.   : 1.900   Min.   : 4.00   Min.   : 2685  
# 1st Qu.:1979-06-08   1st Qu.: 1582.2   1st Qu.:224896   1st Qu.: 5.500   1st Qu.: 6.00   1st Qu.: 6284  
# Median :1991-05-16   Median : 3953.6   Median :253060   Median : 7.700   Median : 7.50   Median : 7494  
# Mean   :1991-05-17   Mean   : 4843.5   Mean   :257189   Mean   : 7.937   Mean   : 8.61   Mean   : 7772  
# 3rd Qu.:2003-04-23   3rd Qu.: 7667.3   3rd Qu.:290291   3rd Qu.:10.500   3rd Qu.: 9.10   3rd Qu.: 8691  
# Max.   :2015-04-01   Max.   :12161.5   Max.   :320887   Max.   :17.000   Max.   :25.20   Max.   :15352  

?economics  # # US economic time series
# Format
# A data frame with 478 rows and 6 variables
# date          Month of data collection 數據收集月
# psavert       personal savings rate 個人儲蓄率
# pce           personal consumption expenditures, in billions of dollars 個人消費支出以數十億美元計
# unemploy      number of unemployed in thousands 失業人數為千人
# uempmed       median duration of unemployment, in weeks 中位數失業的中位數，以周為單位
# pop           total population, in thousands,總人口數千人

#在  economics  資料裡，pce  為個人消費支出(personal  consumption expenditures)，
#而  psavert    為個人儲蓄率(personal savings rate)。我們用 cor 計算它們的相關係數。
names(economics)
# [1] "date"     "pce"      "pop"      "psavert"  "uempmed"  "unemploy"

cor(economics$pce, economics$psavert)
#[1] -0.837069
# 這高度負相關的結果似乎合情合理，這是因為消費和儲蓄的關係本來就應該是反向的。
#  -1 < 相關係數 < 1
# 愈接近1 表示高度正相關   愈接近-1 表示高度負相關   愈接近 0 表示沒有相關 
# ---------------------------------------------------------------------------- #

# 用cor計算相關係數
cor(economics$pce, economics$psavert)

## 相關係數的公式的 R 計算
## 計算用來找出相關係數的每個部份
xPart <- economics$pce - mean(economics$pce)
yPart <- economics$psavert - mean(economics$psavert)
nMinusOne <- (nrow(economics) - 1)
xSD <- sd(economics$pce)
ySD <- sd(economics$psavert)

# 應用相關係數的公式
sum(xPart * yPart) / (nMinusOne * xSD * ySD)
# [1] -0.837069

# ---------------------------------------------------------- #
# 若要同時比較好幾個變數，可以把  matrix(只能用在  numeric  變數)用在 cor 裡。
names(economics)
# [1] "date"     "pce"      "pop"      "psavert"  "uempmed"  "unemploy"

cor(economics[, c(2, 4:6)])
#                 pce    psavert    uempmed   unemploy
# pce       1.0000000 -0.8370690  0.7273492  0.6139997
# psavert  -0.8370690  1.0000000 -0.3874159 -0.3540073
# uempmed   0.7273492 -0.3874159  1.0000000  0.8694063
# unemploy  0.6139997 -0.3540073  0.8694063  1.0000000
# ---------------------------------------------------------- #

# 我們用  GGally  套件中的  ggpairs  函數來繪圖，如圖   顯示，該圖顯示的是兩兩變數的散佈圖。由於載入  GGally  同時會載入  reshape 套件，造成一些 namespace 的問題。因此我們是用::運算子來呼叫它的函數。
#GGally::ggpairs(economics[, c(2, 4:6)], params = list(labelSize = 8))
#install.packages("GGally")
library(GGally)
ggpairs(economics[, c(2, 4:6)])

# ---------------------------------------------------------- #
# 若要看相關性，我們可用它們的相關係數來繪製一個熱力圖(heatmap) 
# 載入reshape套件以溶化資料
require(reshape2)

# 載入scales套件以增添繪圖功能
require(scales)

# 建立相關係數矩陣
(econCor <- cor(economics[, c(2, 4:6)]))
#                 pce    psavert    uempmed   unemploy
# pce       1.0000000 -0.8370690  0.7273492  0.6139997
# psavert  -0.8370690  1.0000000 -0.3874159 -0.3540073
# uempmed   0.7273492 -0.3874159  1.0000000  0.8694063
# unemploy  0.6139997 -0.3540073  0.8694063  1.0000000
str(econCor)

# 把它溶化成長的格式  >>> 寬資料  轉成  長資料
econMelt <- melt(econCor, varnames=c("x", "y"),
                 value.name="Correlation")
econMelt
#           x        y Correlation
# 1       pce      pce   1.0000000
# 2   psavert      pce  -0.8370690
# 3   uempmed      pce   0.7273492
# 4  unemploy      pce   0.6139997
# 5       pce  psavert  -0.8370690
# 6   psavert  psavert   1.0000000
# 7   uempmed  psavert  -0.3874159
# 8  unemploy  psavert  -0.3540073
# 9       pce  uempmed   0.7273492
# 10  psavert  uempmed  -0.3874159
# 11  uempmed  uempmed   1.0000000
# 12 unemploy  uempmed   0.8694063
# 13      pce unemploy   0.6139997
# 14  psavert unemploy  -0.3540073
# 15  uempmed unemploy   0.8694063
# 16 unemploy unemploy   1.0000000

# 依據相關係數做排序
econMeltOrder <- econMelt[order(econMelt$Correlation), ]

# 顯示溶化後排序的資料
econMeltOrder
#           x        y Correlation
# 2   psavert      pce  -0.8370690
# 5       pce  psavert  -0.8370690
# 7   uempmed  psavert  -0.3874159
# 10  psavert  uempmed  -0.3874159
# 8  unemploy  psavert  -0.3540073
# 14  psavert unemploy  -0.3540073
# 4  unemploy      pce   0.6139997
# 13      pce unemploy   0.6139997
# 3   uempmed      pce   0.7273492
# 9       pce  uempmed   0.7273492
# 12 unemploy  uempmed   0.8694063
# 15  uempmed unemploy   0.8694063
# 1       pce      pce   1.0000000
# 6   psavert  psavert   1.0000000
# 11  uempmed  uempmed   1.0000000
# 16 unemploy unemploy   1.0000000

## 用ggplot繪圖
# 用x和y設為x和y軸作為圖的初始建立
ggplot(econMeltOrder, aes(x=x, y=y)) +
    # 畫上磚塊(方塊),依據相關係數(Correlation)填上顏色
    geom_tile(aes(fill=Correlation)) +
    # 以三層色彩漸層(color gradient)的顏色對磚塊填上顏色
    # 靜音(muted)紅作為最低點, 白色為中間, 鋼鐵藍作為最高點
    # 顏色說明為一條不設有刻度(ticks)的色帶(colorbar), 其高度為10行
    # limits則指定所填上的尺度範圍為從-1到1
    scale_fill_gradient2(low=muted("red"), mid="white",
                         high="steelblue", space ="Lab",
                         guide=guide_colorbar(ticks=FALSE, barheight=10),
                         limits=c(-1, 1)) +
    # 使用最簡單的主題(minimal theme)以確保圖中沒多餘的東西
    theme_minimal() +
    # 將x和y標籤留空
    labs(x=NULL, y=NULL)

## 參考資料
## R Rectangles
# http://ggplot2.tidyverse.org/reference/geom_tile.html

# 5. tips 小費案例 ------

data(tips, package = "reshape2")
head(tips)
#   total_bill  tip    sex smoker day   time size
# 1      16.99 1.01 Female     No Sun Dinner    2
# 2      10.34 1.66   Male     No Sun Dinner    3
# 3      21.01 3.50   Male     No Sun Dinner    3
# 4      23.68 3.31   Male     No Sun Dinner    2
# 5      24.59 3.61 Female     No Sun Dinner    4
# 6      25.29 4.71   Male     No Sun Dinner    4

# 5.1 利用ggpaires 劃出 tips 資料裡連續型與離散型變數之間的關係 ------------
GGally::ggpairs(tips)

?ggpairs
# ---------------------------------------------------------- #

# 6. 共變異數(covariace) ------
# * (https://zh.wikipedia.org/wiki/%E5%8D%8F%E6%96%B9%E5%B7%AE)
# * 要讓相關性的討論顯得完整，我們必須提起一個傳統概念  –  
# * 相關性不蘊含因果關係"，意思是，若兩個變數之間存在著相關性，並不表示它們會對對方有所影響。
# * 共變異數是一個類似於相關係數的統計量，這統計量就像變數之間的變異數
# * 共變異數表示的是兩個變量的總體的誤差，這與只表示一個變量誤差的變異數不同。 
# * 如果兩個變量的變化趨勢一致，也就是說如果其中一個大於自身的期望值，另外一個也大於自身的期望值，那麼兩個變量之間的共變異數就是正值。 
# * 如果兩個變量的變化趨勢相反，即其中一個大於自身的期望值，另外一個卻小於自身的期望值，那麼兩個變量之間的共變異數就是負值。

cov(economics$pce, economics$psavert)
# [1] -9361.028

cov(economics[, c(2, 4:6)])
#                   pce      psavert      uempmed    unemploy
# pce      12811296.900 -9361.028324 10695.023873 5806187.162
# psavert     -9361.028     9.761835    -4.972622   -2922.162
# uempmed     10695.024    -4.972622    16.876582    9436.074
# unemploy  5806187.162 -2922.161618  9436.074287 6979955.661

# 檢測cov和cor*sd*sd的結果是否一樣
identical(cov(economics$pce, economics$psavert),
    cor(economics$pce, economics$psavert) *
    sd(economics$pce) * sd(economics$psavert))
# [1]TRUE
# ---------------------------------------------------------- #
?cor
?cov
# var, cov and cor compute the variance of x and the covariance or correlation of x and y if these are vectors. If x and y are matrices then the covariances (or correlations) between the columns of x and the columns of y are computed.

# 7. Test 假設檢定 -----
#    t 檢定  
# * (https://zh.wikipedia.org/wiki/%E5%AD%B8%E7%94%9Ft%E6%AA%A2%E9%A9%97)
# * t  檢定是用來對資料的平均數做檢定，或被用來比較兩組資料。
# 學生t檢驗（或譯司圖頓t檢驗）（英語：Student's t-test）是指虛無假設成立時的任一檢定統計有學生t-分布的統計假說檢定，屬於母數統計。學生t檢驗常作為檢驗一群來自常態分配母體的獨立樣本之期望值的是否為某一實數，或是二群來自常態分配母體的獨立樣本之期望值的差是否為某一實數。
# 
# * 假設檢定 (Hypothesis testing) (http://ccckmit.wikidot.com/st:test)
# * 原理
# * 根據某些樣本，推論統計可以進行實驗的檢定某個假設 H1 是否可能，
# * 其方法是透過否定對立假設 H0，看看 H0 是否不太可能發生。
# * H1：稱為研究假設 (research hypothesis) 或對立假設 (alternhative hypothesis)
# * H0：稱為虛無假設 (null hypothesis)
# * 透過推論統計，我們可以檢查實驗結果是否具有顯著性 (假設檢定)，也就是實驗的假設 H1 是否要被接受，由於 H0 是H1 的對立假設 (不是 H0 就是 H1，也就是 H1 = not H0)，因此一旦否決了 H0 就代表接受了 H1。

# * 平均數 μ 的檢定  http://ccckmit.wikidot.com/st:test1
# 
# *      右尾檢定 左尾檢定	雙尾檢定
# *  H0	  μ<μ0	   μ<μ0	     μ=μ0
# *  H1	  μ>μ0	   μ<μ0	     μ≠μ0
# 
# * 說明 1：其中的 H0 稱為虛無假說 (null hypothesis)，H1 稱為對立假說 (alternative hypothesis) 或實驗假說。
# * 說明 2：R 軟體中的 alternative 指的就是 H1, 所以：
# * R 中的 alternative = greater 代表 μ>μ0，也就是右尾檢定。
# * R 中的 alternative = less 代表 μ<μ0，也就是左尾檢定。
# * R 中的 alternative = two.sided 代表 μ≠μ0，也就是雙尾檢定。

# 1. 用平均數 5 標準差 2 的常態分布產生 25 個樣本。
(x = rnorm(25, mean=5, sd=2))
# [1] 5.380189 1.363521 5.075478 7.870013 4.853611 6.909454 4.896258 3.472471 1.936072 6.111488 6.559955 6.125411 6.976462
# [14] 5.139017 6.385180 6.642472 6.823428 3.563922 4.695028 6.987581 3.680057 5.016144 2.147304 6.573956 6.702967

x <- c(5.380189, 1.363521, 5.075478, 7.870013, 4.853611, 6.909454, 4.896258, 3.472471, 1.936072, 6.111488, 6.559955, 6.125411, 6.976462,5.139017, 6.385180, 6.642472, 6.823428, 3.563922, 4.695028, 6.987581, 3.680057, 5.016144, 2.147304, 6.573956, 6.702967)

sd(x)   #[1] 1.747367
mean(x) #[1] 5.275498

#2. 雙尾檢定：用 t.test(x, alternative="two.sided", mu=4.5) 進行 H1:μ ≠ 4.5 的雙尾檢定。
t.test(x, alternative="two.sided", mu=4.5)

# One Sample t-test
# 
# data:  x
# t = 2.219, df = 24, p-value = 0.03619  # 顯著性為0.03619代表 mean(X) = 5.27 時，mu 的 3.619%信賴區間邊緣恰好為 4.5。
# alternative hypothesis: true mean is not equal to 4.5  #  對立假設為 H1:mu 不等於 4.5
# 95 percent confidence interval: 
# 95% 信賴區間為 (4.55 ~ 5.99)，也就是當 mean(X) = 5.27 時，mu 的 95% 信賴區間為 (4.55 ~ 5.99)。
#  4.554220 67755.99
# sample estimates:
# mean of x  # 平均值為 5.27
# 5.275498 

t.test(x, alternative="two.sided", mu=5.27)


# 3. 左尾檢定：用 t.test(x, alternative="less", mu=4.5) 進行 H1:μ<4.5 的左尾檢定。
t.test(x, alternative="less", mu=4.5)
# One Sample t-test
# 
# data:  x
# t = 2.219, df = 24, p-value = 0.9819 # 顯著性為0.9819代表mu = 4.5, S=1.74的分布會產生 mean(X) < 5.27的機會有98.19%。
# alternative hypothesis: true mean is less than 4.5
# 95 percent confidence interval: 
#                 95% 信賴區間為 (負無限大 ~ 5.87)，也就是當 mu=5.87 時，會產生 mean(X) < 5.27 的機會為 5%。
#     -Inf 5.873405
# sample estimates:
#     mean of x 
# 5.275498 

# 4. 右尾檢定：用 t.test(x, alternative="greater", mu=4.5) 進行 H1:μ>4.5 的右尾檢定。
t.test(x, alternative="greater", mu=4.5)
# One Sample t-test
# 
# data:  x
# t = 2.219, df = 24, p-value = 0.0181

# 顯著性為 0.0181 代表 mu = 4.5, S=1.74 的分布會產生 mean(X) > 5.27 的機會只有 1.81%。
# 由於此可能性很小，所以可以否決 H0 的假設，也就是我們認可對立假設 H1 應該成立。

# alternative hypothesis: true mean is greater than 4.5
# 95 percent confidence interval:
#                  95% 信賴區間為 (4.67759 ~ 無限大)，也就是當 mu=4.67759 時，會產生 mean(X) > 5.27 的機會為 5%。
#     4.67759     Inf
# sample estimates:
#     mean of x 
# 5.275498 

#### end of 假設檢定 (Hypothesis testing)

data(tips, package = "reshape2")
head(tips)
#   total_bill  tip    sex smoker day   time size
# 1      16.99 1.01 Female     No Sun Dinner    2
# 2      10.34 1.66   Male     No Sun Dinner    3
# 3      21.01 3.50   Male     No Sun Dinner    3
# 4      23.68 3.31   Male     No Sun Dinner    2
# 5      24.59 3.61 Female     No Sun Dinner    4
# 6      25.29 4.71   Male     No Sun Dinner    4

str(tips)
# 'data.frame':	244 obs. of  7 variables:
# $ total_bill: num  17 10.3 21 23.7 24.6 ...
# $ tip       : num  1.01 1.66 3.5 3.31 3.61 4.71 2 3.12 1.96 3.23 ...
# $ sex       : Factor w/ 2 levels "Female","Male": 1 2 2 2 1 2 2 2 2 2 ...
# $ smoker    : Factor w/ 2 levels "No","Yes": 1 1 1 1 1 1 1 1 1 1 ...
# $ day       : Factor w/ 4 levels "Fri","Sat","Sun",..: 3 3 3 3 3 3 3 3 3 3 ...
# $ time      : Factor w/ 2 levels "Dinner","Lunch": 1 1 1 1 1 1 1 1 1 1 ...
# $ size      : int  2 3 3 2 4 4 2 4 2 2 ...

# 服務員的性別
unique(tips$sex)

# 每周各天
unique(tips$day)

?unique
# Extract Unique Elements
# 
# Description
# 
# unique returns a vector, data frame or array like x but with duplicate elements/rows removed.
# Examples

(x <- c(3:5, 11:8, 8 + 0:5))
(ux <- unique(x))
(u2 <- unique(x, fromLast = TRUE)) # different order
stopifnot(identical(sort(ux), sort(u2)))

length(unique(sample(100, 100, replace = TRUE)))
## approximately 100(1 - 1/e) = 63.21


#  7. 單一樣本 t 檢定 -------
# * 此檢定實質上只是計算資料的平均值和建立一個信賴區間。若我們想要檢測的值落在該信賴區間裡，
# * 我們就可以下結論說該值就是資料真正的平均值。
# * 單樣本檢驗：檢驗一個常態分布的總體的均值是否在滿足零假設的值之內，例如檢驗一群人的身高的平均是否符合170公分。


t.test(tips$tip, alternative = "two.sided", mu = 2.5)

# One Sample t-test
# 
# data:  tips$tip
# t = 5.6253, df = 243, p-value = 5.08e-08
# alternative hypothesis: true mean is not equal to 2.5
# 95 percent confidence interval:
#     2.823799 3.172758
# sample estimates:
# mean of x 
# 2.998279 

# 這裡的 p 值示意了我們應該要拒絕虛無假設(null hypothesis) ，引致我們要下結論說平均值並不等於$2.50。


t.test(tips$tip, alternative = "two.sided", mu = 2.99)
t.test(tips$tip, alternative = "two.sided", mu = 0.5)

?t.test
# Examples

require(graphics)

t.test(1:10, y = c(7:20))      # P = .00001855
t.test(1:10, y = c(7:20, 200)) # P = .1245    -- NOT significant anymore

## Classical example: Student's sleep data
plot(extra ~ group, data = sleep)
## Traditional interface
with(sleep, t.test(extra[group == 1], extra[group == 2]))
## Formula interface
t.test(extra ~ group, data = sleep)
# ---------------------------------------------------------- #

## 建立一個t分佈
randT <- rt(30000, df=NROW(tips)-1)

# 得到t統計量和其它相關訊息
tipTTest <- t.test(tips$tip, alternative="two.sided", mu=2.50)

# 繪製圖
ggplot(data.frame(x=randT)) +
geom_density(aes(x=x), fill="grey", color="grey") +
geom_vline(xintercept=tipTTest$statistic) +
geom_vline(xintercept=mean(randT) + c(-2, 2)*sd(randT), linetype=2)

# 如圖 顯示，黑實線代表的是 t 統計量，可以看到它座落的地方離分佈有一段距離，因此我們以平均數不等於$2.50 作為結論。
# p  值實質上是在虛無假設為真實得到目前觀察結果或更極端結果的機率，若該統計量非常極端(p  值很小)，
# 我們則拒絕虛無假設。
# 自由度代表的是觀測值的有效個數。一些統計量或分佈的自由度為觀測值個數扣除被估計的參數個數，
# 以  t  分佈作為例子，只有一個參數是被估計的，就是其標準誤差。


# ---------------------------------------------------------- #

t.test(tips$tip, alternative = "greater", mu = 2.5)

# ---------------------------------------------------------- #


#  8. 雙樣本 t 檢定  -------
# * t  檢定還常常被用來比較兩組樣本。傳統的  t  檢定要求兩組的變異數必須一樣，
# * 而  Welch  雙樣本  t  檢定則可以處理變異數不同的樣本群。


# 首先對各組計算變異數;
# 使用formula介面
# 計算每個性別小費的變異數
aggregate(tip ~ sex, data=tips, var)
#      sex      tip
# 1 Female 1.344428
# 2   Male 2.217424

# 現在檢測小費的分佈是否為常態
shapiro.test(tips$tip)
# Shapiro-Wilk normality test
# 
# data:  tips$tip
# W = 0.89781, p-value = 8.2e-12

shapiro.test(tips$tip[tips$sex == "Female"])
# Shapiro-Wilk normality test
# 
# data:  tips$tip[tips$sex == "Female"]
# W = 0.95678, p-value = 0.005448

shapiro.test(tips$tip[tips$sex == "Male"])
# Shapiro-Wilk normality test
# 
# data:  tips$tip[tips$sex == "Male"]
# W = 0.87587, p-value = 3.708e-10


# 用目測可以判斷所有檢測都不通過
ggplot(tips, aes(x=tip, fill=sex)) +
geom_histogram(binwidth=.5, alpha=1/2)

# 由於資料都不呈現常態分佈，標準的  F  檢定(通過  var.test  函數)和 Bartlett  檢定(通過  bartlett.test  函數)都不能被使用。因此，我們用無母數 Ansari-Bradley 檢定來檢測變異數是否相等。

ansari.test(tip ~ sex, tips)
# Ansari-Bradley test
# 
# data:  tip by sex
# AB = 5582.5, p-value = 0.376
# alternative hypothesis: true ratio of scales is not equal to 1

# ---------------------------------------------------------- #
# 檢定結果顯示兩組樣本的變異數相等，因此我們可以用最標準的雙樣本  t 檢定。

# 設定var.equal=TRUE將進行標準的雙樣本t檢定
# 設定var.equal=FALSE(預設)則進行Welch檢定
t.test(tip ~ sex, data = tips, var.equal = TRUE)

# Two Sample t-test
# 
# data:  tip by sex
# t = -1.3879, df = 242, p-value = 0.1665
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#     -0.6197558  0.1074167
# sample estimates:
# mean in group Female   mean in group Male 
# 2.833448             3.089618 

# ---------------------------------------------------------- #
# 根據此檢定，結果為不顯著的，因此結論為男性和女性服務員所收到的小費額是差不多一樣的。


#  9. 成對雙樣本 t 檢定 ------
# * 若要檢定成對樣本，我們需要成對雙樣本  t  檢定。對此，我們只需要在  t.test  的 paired  引數設為  TRUE  即可。我們使用  Karl  Pearson  所收集的資料來做示範，此資料放置在  UsingR  套件裡，該資料為父親和兒子的高度。

install.packages("UsingR")
require(UsingR)
head(father.son)
#    fheight  sheight
# 1 65.04851 59.77827
# 2 63.25094 63.21404
# 3 64.95532 63.34242
# 4 65.75250 62.79238
# 5 61.13723 64.28113
# 6 63.02254 64.24221

t.test(father.son$fheight, father.son$sheight, paired = TRUE)

# Paired t-test
# 
# data:  father.son$fheight and father.son$sheight
# t = -11.789, df = 1077, p-value < 2.2e-16
# alternative hypothesis: true difference in means is not equal to 0
# 95 percent confidence interval:
#     -1.1629160 -0.8310296
# sample estimates:
#     mean of the differences 
# -0.9969728 

# ---------------------------------------------------------- #

heightDiff <- father.son$fheight - father.son$sheight
ggplot(father.son, aes(x=fheight - sheight)) +
geom_density() +
geom_vline(xintercept=mean(heightDiff)) +
geom_vline(xintercept=mean(heightDiff) +
2*c(-1, 1)*sd(heightDiff)/sqrt(nrow(father.son)),
linetype=2)
# 檢定結果顯示我們應該要拒絕虛無假設，並總結父親和兒子(至少對於此樣本來說)的高度是不相等的。


#  10.  變異數分析(ANOVA) ------
# * R  提供了一個函數來進行 ANOVA 檢定，此函數用的也是 formula 介面，
# * 左邊放的是我們感興趣的變數，而右邊放的是控制分群的變數。我們比較一週裡小費額在不同天是否有差

data(tips, package = "reshape2")
head(tips)
tipAnova <- aov(tip ~ day - 1, tips)
# Call:
#     aov(formula = tip ~ day - 1, data = tips)
# 
# Terms:
#     day Residuals
# Sum of Squares  2203.0066  455.6866
# Deg. of Freedom         4       240
# 
# Residual standard error: 1.377931
# Estimated effects are balanced

# ---------------------------------------------------------- #

tipIntercept <- aov(tip ~ day, tips)
# Call:
#     aov(formula = tip ~ day, data = tips)
# 
# Terms:
#     day Residuals
# Sum of Squares    9.5259  455.6866
# Deg. of Freedom        3       240
# 
# Residual standard error: 1.377931
# Estimated effects may be unbalanced

tipAnova$coefficients
#   dayFri   daySat   daySun  dayThur 
# 2.734737 2.993103 3.255132 2.771452 

tipIntercept$coefficients
# (Intercept)     daySat      daySun     dayThur 
# 2.73473684  0.25836661  0.52039474  0.03671477 

# ---------------------------------------------------------- #
# ANOVA  檢定的用處是要檢測是否有任一群組跟其它群組不一樣，但它並不能告訴我們是哪個群組不一樣。
# 因此，檢定的摘要表只會顯示單一個 p 值。

summary(tipAnova)
#            Df Sum Sq Mean Sq F value Pr(>F)    
# day         4 2203.0   550.8   290.1 <2e-16 ***
# Residuals 240  455.7     1.9                   
# ---
#     Signif. codes:  0 ‘***’ 0.001 ‘**’ 0.01 ‘*’ 0.05 ‘.’ 0.1 ‘ ’ 1

# ---------------------------------------------------------- #
# 由於此檢定有顯著的  p  值，我們現在想要看哪一組跟其它組別不同。
# 對此，最簡單的方法就是把每一組個別的平均數和信賴區間繪出，然後看有哪些是重疊的。

require(plyr)
tipsByDay <- ddply(tips, "day", summarise,
tip.mean=mean(tip), tip.sd=sd(tip),
Length=NROW(tip),
tfrac=qt(p=.90, df=Length-1),
Lower=tip.mean - tfrac*tip.sd/sqrt(Length),
Upper=tip.mean + tfrac*tip.sd/sqrt(Length)
)
require(ggplot2)
ggplot(tipsByDay, aes(x=tip.mean, y=day)) + geom_point() +
geom_errorbarh(aes(xmin=Lower, xmax=Upper), height=.3)

# ---------------------------------------------------------- #
# 使用 NROW 而非 nrow 是要確保它會進行運算，nrow 只對 data.frame 和 matrices 起作用，
# 而 NROW 可以回傳只有一維度物件的長度。

nrow(tips)
NROW(tips)
nrow(tips$tip)
NROW(tips$tip)

# R 程式範例
# 資料庫：R 軟體內建的 InsectSprays 資料庫 — 檔案下載：InsectSprays.dat
# 資料意義：實驗者使用了 A, B, C, D, E, F 等六種殺蟲劑在田野中進行效能測試，
# 每種殺蟲劑重複測試了 12 次，觀測變量是昆蟲的數量。
# 分析目標：研究殺蟲劑的效能，採用變異數分析的方式，進行分析研究。
# 分析過程

data(InsectSprays)
dim(InsectSprays) #[1] 72  2

?InsectSprays
require(stats); require(graphics)
boxplot(count ~ spray, data = InsectSprays,
xlab = "Type of spray", ylab = "Insect count",
main = "InsectSprays data", varwidth = TRUE, col = "lightgray")
fm1 <- aov(count ~ spray, data = InsectSprays)
summary(fm1)
opar <- par(mfrow = c(2, 2), oma = c(0, 0, 1.1, 0))
plot(fm1)
fm2 <- aov(sqrt(count) ~ spray, data = InsectSprays)
summary(fm2)
plot(fm2)
par(opar)

### End of ?InsectSprays

head(InsectSprays)
#   count spray
# 1    10     A
# 2     7     A
# 3    20     A
# 4    14     A
# 5    14     A
# 6    12     A

aov.spray <- aov(sqrt(count) ~ spray, data = InsectSprays)
aov.spray
# Call:
#     aov(formula = sqrt(count) ~ spray, data = InsectSprays)
# 
# Terms:
#                    spray Residuals
# Sum of Squares  88.43787  26.05798
# Deg. of Freedom        5        66
# 
# Residual standard error: 0.6283453
# Estimated effects may be unbalanced

opar <- par()
par(mfcol = c(2,2))
plot(aov.spray)

par(opar)
termplot(aov.spray, se=TRUE, partial.resid=TRUE, rug=TRUE)


str(aov.spray)

str(aov.spray, max.level = -1)
# List of 13
# - attr(*, "class")= chr [1:2] "aov" "lm"

names(aov.spray)
# [1] "coefficients"  "residuals"     "effects"       "rank"          "fitted.values" "assign"        "qr"           
# [8] "df.residual"   "contrasts"     "xlevels"       "call"          "terms"         "model"  

aov.spray$coefficients
# (Intercept)      sprayB      sprayC      sprayD      sprayE      sprayF 
#   3.7606784   0.1159530  -2.5158217  -1.5963245  -1.9512174   0.2579388 

str(summary(aov.spray))
# List of 1
# $ :Classes ‘anova’ and 'data.frame':	2 obs. of  5 variables:
# ..$ Df     : num [1:2] 5 66
# ..$ Sum Sq : num [1:2] 88.4 26.1
# ..$ Mean Sq: num [1:2] 17.688 0.395
# ..$ F value: num [1:2] 44.8 NA
# ..$ Pr(>F) : num [1:2] 6.33e-20 NA
# - attr(*, "class")= chr [1:2] "summary.aov" "listof"

